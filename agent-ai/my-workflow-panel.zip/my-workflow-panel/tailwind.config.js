/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",  // Adjust if your files are in a different folder
  ],
  theme: {
    extend: {},  // You can add custom themes here if needed
  },
  plugins: [],
};