import React, { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Circle,
  Clock,
  PlayCircle,
  XCircle,
  AlertTriangle,
  ChevronRight,
  Info,
  Activity,
  FileText,
  ListTree,
  GitBranch,
  SplitSquareHorizontal,
  Merge,
  Timer,
} from "lucide-react";

/**
 * N8N-style Agentic Workflow Panel (Dark Mode)
 * - Supports multiple workflows in a left sidebar
 * - Fan-out / Join branches with solid connectors
 * - Routing & Async nodes
 * - Right-hand expandable details panel per node
 */

// -------------------- Types --------------------

type Status = "done" | "running" | "queued" | "blocked" | "failed" | "idle";
type NodeType = "task" | "router" | "async" | "fanout" | "join";

interface WFNode {
  id: string;
  name: string;
  type: NodeType;
  description: string;
  status: Status;
  owner?: string;
  metrics?: Record<string, any>;
  inputs?: string[];
  outputs?: string[];
  log?: string[];
  routes?: { to: string; label: string }[]; // router-specific
}

interface Workflow {
  id: string;
  title: string;
  status: Status;
  nodes: Record<string, WFNode>;
  columns: (string | string[])[]; // string = node id, string[] = fanout column stack
}

// -------------------- Demo Workflows --------------------

const WF_A: Workflow = {
  id: "wf-a",
  title: "Spring API Generator",
  status: "running",
  nodes: {
    intake: {
      id: "intake",
      name: "Intake",
      type: "task",
      description: "Capture requirements (OAS/WSDL).",
      status: "done",
      owner: "Ops Bot",
    },
    plan: {
      id: "plan",
      name: "Planning",
      type: "router",
      description: "Decompose endpoints; route by domain.",
      status: "running",
      owner: "Planner",
      routes: [
        { to: "gen-core", label: "Core" },
        { to: "gen-service", label: "Service" },
        { to: "gen-repo", label: "Repository" },
        { to: "gen-controller", label: "Controller" },
      ],
    },
    "gen-core": {
      id: "gen-core",
      name: "Generate Core",
      type: "fanout",
      description: "Domain models & logic.",
      status: "queued",
      owner: "Core Gen",
      metrics: { estMin: 3 },
    },
    "gen-service": {
      id: "gen-service",
      name: "Generate Service",
      type: "fanout",
      description: "Service orchestration.",
      status: "queued",
      owner: "Svc Gen",
      metrics: { estMin: 4 },
    },
    "gen-repo": {
      id: "gen-repo",
      name: "Generate Repository",
      type: "fanout",
      description: "Persistence adapters.",
      status: "queued",
      owner: "Repo Gen",
      metrics: { estMin: 3 },
    },
    "gen-controller": {
      id: "gen-controller",
      name: "Generate Controller",
      type: "fanout",
      description: "REST DTOs & controllers.",
      status: "queued",
      owner: "Ctrl Gen",
      metrics: { estMin: 2 },
    },
    assemble: {
      id: "assemble",
      name: "Assemble",
      type: "join",
      description: "Merge generator outputs.",
      status: "idle",
      owner: "Builder",
    },
    review: {
      id: "review",
      name: "Review",
      type: "task",
      description: "Static checks & security.",
      status: "blocked",
      owner: "Reviewer",
    },
    test: {
      id: "test",
      name: "Test",
      type: "async",
      description: "Unit/contract tests (async).",
      status: "idle",
      owner: "Tester",
    },
    deploy: {
      id: "deploy",
      name: "Deploy",
      type: "task",
      description: "Ship to target.",
      status: "idle",
      owner: "Release Bot",
    },
  },
  columns: [
    "intake",
    "plan",
    ["gen-core", "gen-service", "gen-repo", "gen-controller"], // fanout stack
    "assemble",
    "review",
    "test",
    "deploy",
  ],
};

const WF_B: Workflow = {
  id: "wf-b",
  title: "Data Pipeline Refresh",
  status: "queued",
  nodes: {
    source: {
      id: "source",
      name: "Source Scan",
      type: "task",
      description: "Discover tables.",
      status: "done",
    },
    route: {
      id: "route",
      name: "Router",
      type: "router",
      description: "Split by domain.",
      status: "queued",
      routes: [
        { to: "ingest-a", label: "Sales" },
        { to: "ingest-b", label: "Ops" },
      ],
    },
    "ingest-a": {
      id: "ingest-a",
      name: "Ingest A",
      type: "fanout",
      description: "ETL Sales.",
      status: "queued",
    },
    "ingest-b": {
      id: "ingest-b",
      name: "Ingest B",
      type: "fanout",
      description: "ETL Ops.",
      status: "queued",
    },
    merge: {
      id: "merge",
      name: "Merge",
      type: "join",
      description: "Combine datasets.",
      status: "idle",
    },
    validate: {
      id: "validate",
      name: "Validate",
      type: "task",
      description: "DQ checks.",
      status: "idle",
    },
  },
  columns: ["source", "route", ["ingest-a", "ingest-b"], "merge", "validate"],
};

const DEMO_WORKFLOWS: Workflow[] = [WF_A, WF_B];

// -------------------- Visual Meta --------------------

const STATUS_META: Record<Status, any> = {
  done: {
    label: "Done",
    icon: CheckCircle2,
    tone: "text-emerald-400",
    chip: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  },
  running: {
    label: "Running",
    icon: Activity,
    tone: "text-sky-300",
    chip: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  },
  queued: {
    label: "Queued",
    icon: Clock,
    tone: "text-slate-300",
    chip: "bg-slate-500/10 text-slate-300 border-slate-500/30",
  },
  blocked: {
    label: "Blocked",
    icon: AlertTriangle,
    tone: "text-amber-300",
    chip: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  },
  failed: {
    label: "Failed",
    icon: XCircle,
    tone: "text-rose-400",
    chip: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  },
  idle: {
    label: "Idle",
    icon: Circle,
    tone: "text-slate-400",
    chip: "bg-slate-500/10 text-slate-400 border-slate-500/30",
  },
};

const TYPE_META: Record<NodeType, { badge: string; icon: any; label: string }> = {
  task: {
    badge: "bg-slate-500/10 text-slate-300 border-slate-500/30",
    icon: Activity,
    label: "Task",
  },
  router: {
    badge: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30",
    icon: GitBranch,
    label: "Router",
  },
  async: {
    badge: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30",
    icon: Timer,
    label: "Async",
  },
  fanout: {
    badge: "bg-teal-500/15 text-teal-300 border-teal-500/30",
    icon: SplitSquareHorizontal,
    label: "Fan-out",
  },
  join: {
    badge: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
    icon: Merge,
    label: "Join",
  },
};

// -------------------- Small Bits --------------------

const SolidConnector = () => <div className="h-0.5 w-12 bg-slate-600" />;

const Badge = ({ className = "", children }: { className?: string; children: React.ReactNode }) => (
  <span className={`rounded-full border px-2 py-0.5 text-[10px] ${className}`}>{children}</span>
);

const textColorFromBadge = (badge: string) => (badge.match(/text-[^\s]+/) || [""])[0];

// -------------------- Components --------------------

const NodeCard = ({
  node,
  active,
  onClick,
}: {
  node: WFNode;
  active: boolean;
  onClick: () => void;
}) => {
  const meta = STATUS_META[node.status] ?? STATUS_META.idle;
  const tMeta = TYPE_META[node.type];
  const StatusIcon = meta.icon;
  const TypeIcon = tMeta.icon;
  return (
    <button
      onClick={onClick}
      className={`group relative w-[250px] rounded-2xl border transition-all duration-200 ${
        active ? "border-sky-500/60" : "border-white/10"
      } bg-gradient-to-b from-slate-900/70 to-slate-900/30 p-4 text-left hover:-translate-y-0.5 active:scale-98`}
    >
      <div className="flex items-start gap-3">
        <div className={`grid h-10 w-10 place-items-center rounded-xl bg-slate-800/70 ${meta.tone}`}>
          <StatusIcon className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-100">{node.name}</h3>
            <Badge className={meta.chip}>{meta.label}</Badge>
          </div>
          <p className="mt-1 line-clamp-2 text-xs text-slate-400">{node.description}</p>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
        <Badge className={`inline-flex items-center gap-2 ${TYPE_META[node.type].badge}`}>
          <TypeIcon className="h-3.5 w-3.5" /> {TYPE_META[node.type].label}
        </Badge>
        {node.owner && (
          <span className="inline-flex items-center gap-1 text-slate-400">
            <Info className="h-3.5 w-3.5" /> {node.owner}
          </span>
        )}
      </div>
      {active && (
        <div className="pointer-events-none absolute inset-0 rounded-2xl ring-2 ring-sky-400/40" />
      )}
    </button>
  );
};

const StageDetails = ({
  node,
  onClose,
}: {
  node?: WFNode | null;
  onClose: () => void;
}) => {
  if (!node) return null;
  const meta = STATUS_META[node.status] ?? STATUS_META.idle;
  const Icon = meta.icon;
  
  return (
    <div className="fixed right-4 top-4 z-50 h-[92vh] w-[380px] overflow-hidden rounded-2xl border border-white/10 bg-slate-950/95 backdrop-blur-lg shadow-2xl transition-all duration-300">
      <div className="flex items-center justify-between border-b border-white/10 p-4">
        <div className="flex items-center gap-3">
          <div
            className={`grid h-9 w-9 place-items-center rounded-xl bg-slate-800/70 ${meta.tone}`}
          >
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-100">{node.name}</h3>
            <div className="mt-1 inline-flex items-center gap-2">
              <Badge className={STATUS_META[node.status].chip}>
                {STATUS_META[node.status].label}
              </Badge>
              <Badge className={TYPE_META[node.type].badge}>
                {TYPE_META[node.type].label}
              </Badge>
            </div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="rounded-xl border border-white/10 bg-slate-900/60 p-2 text-slate-300 hover:text-slate-100"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-3 overflow-y-auto p-4">
        <DetailField label="Description">{node.description}</DetailField>
        <DetailField label="Inputs">
          {node.inputs?.length ? (
            <ul className="list-inside list-disc text-slate-300">
              {node.inputs.map((i) => (
                <li key={i}>{i}</li>
              ))}
            </ul>
          ) : (
            <span className="text-slate-400">—</span>
          )}
        </DetailField>
        <DetailField label="Outputs">
          {node.outputs?.length ? (
            <ul className="list-inside list-disc text-slate-300">
              {node.outputs.map((o) => (
                <li key={o}>{o}</li>
              ))}
            </ul>
          ) : (
            <span className="text-slate-400">—</span>
          )}
        </DetailField>
        {node.routes?.length ? (
          <DetailField label="Routes">
            <ul className="list-inside list-disc space-y-1 text-slate-300">
              {node.routes.map((r) => (
                <li key={r.to} className="text-xs">
                  {r.label} → <span className="text-sky-300">{r.to}</span>
                </li>
              ))}
            </ul>
          </DetailField>
        ) : null}
        <DetailField label="Metrics">
          <pre className="whitespace-pre-wrap text-xs text-slate-300">
            {JSON.stringify(node.metrics ?? {}, null, 2)}
          </pre>
        </DetailField>
        <DetailField label="Logs">
          {node.log?.length ? (
            <ul className="list-inside list-disc space-y-1 text-slate-300">
              {node.log.map((l, idx) => (
                <li key={idx} className="text-xs">
                  {l}
                </li>
              ))}
            </ul>
          ) : (
            <span className="text-slate-400">No logs yet.</span>
          )}
        </DetailField>
      </div>
    </div>
  );
};

const DetailField = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="grid grid-cols-3 gap-3 rounded-xl border border-white/10 bg-slate-900/60 p-3">
    <div className="text-xs font-medium text-slate-400">{label}</div>
    <div className="col-span-2 text-sm text-slate-200">{children}</div>
  </div>
);

const Legend = () => (
  <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3 text-xs text-slate-300">
    {Object.entries(STATUS_META).map(([key, v]) => (
      <div key={key} className="flex items-center gap-2">
        <div className={`grid h-5 w-5 place-items-center rounded-md ${v.tone} bg-slate-800/60`}>
          {React.createElement(v.icon, { className: "h-3.5 w-3.5" })}
        </div>
        <span className="text-slate-400">{v.label}</span>
      </div>
    ))}
    <span className="mx-2 h-4 w-[1px] bg-white/10" />
    {Object.entries(TYPE_META).map(([key, v]) => (
      <div key={key} className="flex items-center gap-2">
        <div
          className={`grid h-5 w-5 place-items-center rounded-md bg-slate-800/60 ${textColorFromBadge(
            v.badge
          )}`}
        >
          {React.createElement(v.icon, { className: "h-3.5 w-3.5" })}
        </div>
        <span className="text-slate-400">{v.label}</span>
      </div>
    ))}
  </div>
);

// -------------------- Dev Tests (runtime validations) --------------------

function idsFromColumns(columns: (string | string[])[]): string[] {
  const out: string[] = [];
  columns.forEach((c) => {
    if (Array.isArray(c)) out.push(...c);
    else out.push(c);
  });
  return out;
}

function validateWorkflow(wf: Workflow): string[] {
  const errs: string[] = [];
  const ids = new Set(Object.keys(wf.nodes));
  const colIds = idsFromColumns(wf.columns);

  // every column id must exist
  for (const id of colIds) if (!ids.has(id)) errs.push(`Column references missing node: ${id}`);

  // if a router is followed by a fanout column, routes length should match
  for (let i = 0; i < wf.columns.length - 1; i++) {
    const cur = wf.columns[i];
    const nxt = wf.columns[i + 1];
    if (!Array.isArray(cur) && Array.isArray(nxt)) {
      const node = wf.nodes[cur];
      if (node?.type === "router") {
        const rlen = node.routes?.length ?? 0;
        const nlen = nxt.length;
        if (rlen && rlen !== nlen) {
          errs.push(
            `Router "${node.name}" has ${rlen} routes but next fanout has ${nlen} branches.`
          );
        }
      }
    }
  }

  // types sanity
  for (const id of colIds) {
    const t = wf.nodes[id]?.type;
    if (t && !TYPE_META[t]) errs.push(`Unknown type for node ${id}: ${t}`);
  }

  return errs;
}

// -------------------- Main --------------------

export default function App() {
  const [workflows] = useState<Workflow[]>(DEMO_WORKFLOWS);
  const [activeWfId, setActiveWfId] = useState<string>(workflows[0].id);
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);

  const activeWf = useMemo(
    () => workflows.find((w) => w.id === activeWfId)!,
    [workflows, activeWfId]
  );
  const activeNode = useMemo(
    () => (activeNodeId ? activeWf.nodes[activeNodeId] : null),
    [activeWf, activeNodeId]
  );

  // Dev tests: validate graph wiring whenever workflow changes
  useEffect(() => {
    const errs = validateWorkflow(activeWf);
    if (errs.length) {
      console.groupCollapsed(`Workflow validation: ${activeWf.title}`);
      errs.forEach((e) => console.error(e));
      console.groupEnd();
    } else {
      console.info(`Workflow validation passed: ${activeWf.title}`);
    }
  }, [activeWf]);

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-200">
      <div className="flex h-screen">
        {/* Sidebar */}
        <aside className="w-64 shrink-0 border-r border-white/10 bg-slate-950/60 p-4 overflow-y-auto">
          <div className="mb-3 flex items-center gap-2">
            <ListTree className="h-5 w-5 text-sky-300" />
            <h2 className="text-sm font-semibold text-slate-100">Workflows</h2>
          </div>

          <div className="space-y-2">
            {workflows.map((wf) => (
              <button
                key={wf.id}
                onClick={() => {
                  setActiveWfId(wf.id);
                  setActiveNodeId(null);
                }}
                className={`w-full rounded-xl border px-3 py-2 text-left ${
                  wf.id === activeWfId
                    ? "border-sky-500/50 bg-sky-500/10"
                    : "border-white/10 bg-slate-900/50 hover:border-sky-500/30"
                }`}
              >
                <div className="flex items-center justify-between text-sm text-slate-100">
                  <span className="truncate">{wf.title}</span>
                  <Badge className={STATUS_META[wf.status].chip}>
                    {STATUS_META[wf.status].label}
                  </Badge>
                </div>
                <div className="mt-1 text-xs text-slate-400">
                  {idsFromColumns(wf.columns).length} nodes
                </div>
              </button>
            ))}
          </div>

          <div className="mt-4 rounded-xl border border-white/10 bg-slate-900/40 p-3 text-xs text-slate-400">
            Select a workflow to view its stages. Click a node to open details.
          </div>
        </aside>

        {/* Canvas */}
        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-none">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-slate-100">
                  {activeWf.title}
                </h3>
                <p className="text-xs text-slate-400">
                  N8N-inspired · dark mode · fan-out/async/routing
                </p>
              </div>
              <button className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-slate-900/60 px-3 py-2 text-sm text-slate-200 hover:border-sky-500/40 hover:text-sky-300">
                <PlayCircle className="h-4 w-4" /> Run
              </button>
            </div>

            <div className="mb-4">
              <Legend />
            </div>

            <div className="relative overflow-x-auto rounded-2xl border border-white/10 bg-gradient-to-b from-slate-950/70 to-slate-900/40 p-8">
              <div className="flex items-center justify-start gap-6 min-w-max">
                {activeWf.columns.map((col, ci) => {
                  const isStack = Array.isArray(col);
                  return (
                    <React.Fragment key={ci}>
                      {/* Column */}
                      <div className="flex flex-col items-center justify-center">
                        {isStack ? (
                          <div className="flex flex-col items-center gap-6">
                            {(col as string[]).map((id) => (
                              <NodeCard
                                key={id}
                                node={activeWf.nodes[id]}
                                active={activeNodeId === id}
                                onClick={() => setActiveNodeId(id)}
                              />
                            ))}
                          </div>
                        ) : (
                          <NodeCard
                            node={activeWf.nodes[col as string]}
                            active={activeNodeId === col}
                            onClick={() => setActiveNodeId(col as string)}
                          />
                        )}
                      </div>

                      {/* Connectors between columns */}
                      {ci < activeWf.columns.length - 1 && (
                        <div className="flex flex-col items-center justify-center">
                          {Array.isArray(activeWf.columns[ci + 1]) ? (
                            // Fan-out: Multiple connectors with labels
                            <div className="flex flex-col gap-6">
                              {(activeWf.columns[ci + 1] as string[]).map((id, idx) => (
                                <div key={id} className="flex items-center gap-2">
                                  <SolidConnector />
                                  <span className="text-[10px] text-slate-400 min-w-[50px] text-left">
                                    {!Array.isArray(col) &&
                                    activeWf.nodes[col as string]?.routes?.[idx]?.label
                                      ? activeWf.nodes[col as string].routes![idx].label
                                      : ""}
                                  </span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            // Single connector
                            <SolidConnector />
                          )}
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>

              {/* backdrop grid */}
              <div 
                className="pointer-events-none absolute inset-0 opacity-20" 
                style={{
                  backgroundImage: 'radial-gradient(rgba(148,163,184,0.1) 1px, transparent 1px)',
                  backgroundSize: '20px 20px'
                }} 
              />
            </div>

            <div className="mt-4 flex items-center text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <FileText className="h-3.5 w-3.5" />
                Click a node to view details. Routers split to multiple branches (fan-out); joins merge back. Async nodes keep running in background.
              </div>
            </div>
          </div>
        </main>

        {/* Details drawer */}
        {activeNode && (
          <StageDetails node={activeNode} onClose={() => setActiveNodeId(null)} />
        )}
      </div>
    </div>
  );
}